-- Enable Supabase Realtime change events for neighbor online presence.
-- Run after 20261126090000_initial.sql in the Supabase SQL Editor.
do $$
begin
  if not exists (
    select 1
    from pg_publication_tables
    where pubname = 'supabase_realtime'
      and schemaname = 'public'
      and tablename = 'player_presence'
  ) then
    alter publication supabase_realtime add table public.player_presence;
  end if;
end;
$$;
