-- Farm Neighbors MVP schema
-- Run the full migration in the Supabase SQL Editor.
-- Client apps receive only publishable/anon key. Never expose service_role keys.


create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text not null default 'Farmer',
  language text not null default 'en' check (language in ('en','ar')),
  created_at timestamptz not null default now()
);

create table if not exists public.farms (
  owner_id uuid primary key references public.profiles(id) on delete cascade,
  farm_name text not null default 'My Farm',
  coins bigint not null default 120 check (coins >= 0),
  gems bigint not null default 0 check (gems >= 0),
  xp integer not null default 0 check (xp >= 0),
  level integer not null default 1 check (level >= 1),
  updated_at timestamptz not null default now()
);

create table if not exists public.farm_plots (
  owner_id uuid not null references public.farms(owner_id) on delete cascade,
  plot_index smallint not null check (plot_index between 0 and 15),
  crop_id text,
  planted_at timestamptz,
  watered boolean not null default false,
  primary key (owner_id, plot_index),
  check ((crop_id is null and planted_at is null) or (crop_id is not null and planted_at is not null))
);

create table if not exists public.inventory (
  owner_id uuid not null references public.farms(owner_id) on delete cascade,
  item_id text not null,
  quantity integer not null default 0 check (quantity >= 0),
  primary key (owner_id, item_id)
);

create table if not exists public.neighbor_codes (
  owner_id uuid primary key references public.profiles(id) on delete cascade,
  code text not null unique,
  expires_at timestamptz not null,
  created_at timestamptz not null default now()
);

create table if not exists public.neighbors (
  owner_id uuid not null references public.profiles(id) on delete cascade,
  neighbor_id uuid not null references public.profiles(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (owner_id, neighbor_id),
  check (owner_id <> neighbor_id)
);

create table if not exists public.player_presence (
  owner_id uuid primary key references public.profiles(id) on delete cascade,
  x real not null default 0,
  y real not null default 0,
  last_seen_at timestamptz not null default now()
);

create index if not exists neighbors_neighbor_id_idx on public.neighbors(neighbor_id);
create index if not exists presence_last_seen_idx on public.player_presence(last_seen_at);

create or replace function public.handle_new_farmer()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  insert into public.profiles(id, display_name)
  values (new.id, coalesce(nullif(new.raw_user_meta_data ->> 'display_name', ''), split_part(coalesce(new.email, 'Farmer'), '@', 1)))
  on conflict (id) do nothing;

  insert into public.farms(owner_id) values (new.id) on conflict (owner_id) do nothing;

  insert into public.farm_plots(owner_id, plot_index)
  select new.id, n from generate_series(0, 15) as n
  on conflict (owner_id, plot_index) do nothing;

  insert into public.inventory(owner_id, item_id, quantity) values
    (new.id, 'seed_wheat', 10),
    (new.id, 'seed_carrot', 0),
    (new.id, 'seed_tomato', 0),
    (new.id, 'seed_corn', 0),
    (new.id, 'wheat', 0),
    (new.id, 'carrot', 0),
    (new.id, 'tomato', 0),
    (new.id, 'corn', 0)
  on conflict (owner_id, item_id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created_farm_neighbors on auth.users;
create trigger on_auth_user_created_farm_neighbors
after insert on auth.users
for each row execute procedure public.handle_new_farmer();

-- Public read policies expose only the caller's own core farm data.
alter table public.profiles enable row level security;
alter table public.farms enable row level security;
alter table public.farm_plots enable row level security;
alter table public.inventory enable row level security;
alter table public.neighbor_codes enable row level security;
alter table public.neighbors enable row level security;
alter table public.player_presence enable row level security;

drop policy if exists "profile self or neighbor read" on public.profiles;
create policy "profile self or neighbor read" on public.profiles
for select to authenticated
using (id = auth.uid() or exists (
  select 1 from public.neighbors n where n.owner_id = auth.uid() and n.neighbor_id = id
));

drop policy if exists "farm owner read" on public.farms;
create policy "farm owner read" on public.farms for select to authenticated using (owner_id = auth.uid());
drop policy if exists "plot owner read" on public.farm_plots;
create policy "plot owner read" on public.farm_plots for select to authenticated using (owner_id = auth.uid());
drop policy if exists "inventory owner read" on public.inventory;
create policy "inventory owner read" on public.inventory for select to authenticated using (owner_id = auth.uid());
drop policy if exists "neighbor self read" on public.neighbors;
create policy "neighbor self read" on public.neighbors for select to authenticated using (owner_id = auth.uid());
drop policy if exists "presence self or neighbor read" on public.player_presence;
create policy "presence self or neighbor read" on public.player_presence for select to authenticated
using (owner_id = auth.uid() or exists (
  select 1 from public.neighbors n where n.owner_id = auth.uid() and n.neighbor_id = owner_id
));
-- No direct client INSERT/UPDATE/DELETE policies on economy tables. Mutations go through checked SQL functions.

create or replace function public.crop_config(p_crop_id text)
returns table(crop_id text, growth_seconds integer, yield_min integer, yield_max integer, sell_price integer, seed_price integer)
language sql immutable
as $$
  select * from (values
    ('wheat', 45, 2, 4, 4, 3),
    ('carrot', 65, 2, 3, 6, 5),
    ('tomato', 90, 2, 4, 8, 7),
    ('corn', 120, 2, 3, 10, 8)
  ) as c(crop_id, growth_seconds, yield_min, yield_max, sell_price, seed_price)
  where c.crop_id = p_crop_id;
$$;

create or replace function public.get_my_farm()
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare v_user uuid := auth.uid();
begin
  if v_user is null then raise exception 'Authentication required'; end if;
  return jsonb_build_object(
    'farm', (select to_jsonb(f) from public.farms f where f.owner_id = v_user),
    'plots', coalesce((select jsonb_agg(to_jsonb(p) order by p.plot_index) from public.farm_plots p where p.owner_id = v_user), '[]'::jsonb),
    'inventory', coalesce((select jsonb_agg(to_jsonb(i) order by i.item_id) from public.inventory i where i.owner_id = v_user), '[]'::jsonb)
  );
end;
$$;

create or replace function public.perform_farm_action(p_plot_index integer, p_action text, p_crop_id text default 'wheat')
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_user uuid := auth.uid();
  v_plot public.farm_plots%rowtype;
  v_crop record;
  v_qty integer;
  v_coins bigint;
  v_xp integer;
  v_old_level integer;
  v_new_level integer;
begin
  if v_user is null then raise exception 'Authentication required'; end if;
  if p_plot_index < 0 or p_plot_index > 15 then raise exception 'Invalid plot index'; end if;
  if p_action not in ('plant','water','harvest') then raise exception 'Invalid farm action'; end if;

  select * into v_plot from public.farm_plots
  where owner_id = v_user and plot_index = p_plot_index
  for update;
  if not found then raise exception 'Farm plot not found'; end if;

  -- Crop identity is server-owned for existing plots; never trust client crop ID for water/harvest.
  if p_action <> 'plant' and v_plot.crop_id is null then raise exception 'Plot is empty'; end if;
  if p_action = 'plant' then
    select * into v_crop from public.crop_config(p_crop_id);
  else
    select * into v_crop from public.crop_config(v_plot.crop_id);
  end if;
  if not found then raise exception 'Unknown crop'; end if;

  if p_action = 'plant' then
    if v_plot.crop_id is not null then raise exception 'Plot is not empty'; end if;
    update public.inventory set quantity = quantity - 1
      where owner_id = v_user and item_id = 'seed_' || p_crop_id and quantity > 0;
    if not found then raise exception 'No seeds available'; end if;
    update public.farm_plots set crop_id = p_crop_id, planted_at = now(), watered = false
      where owner_id = v_user and plot_index = p_plot_index;

  elsif p_action = 'water' then
    if v_plot.crop_id is null then raise exception 'Plot is empty'; end if;
    if v_plot.watered then raise exception 'Already watered'; end if;
    update public.farm_plots set watered = true,
      planted_at = planted_at - make_interval(secs => (v_crop.growth_seconds * 0.2)::integer)
      where owner_id = v_user and plot_index = p_plot_index;

  elsif p_action = 'harvest' then
    if v_plot.crop_id is null then raise exception 'Plot is empty'; end if;
    if now() < v_plot.planted_at + make_interval(secs => v_crop.growth_seconds) then
      raise exception 'Crop is not ready';
    end if;
    v_qty := floor(random() * (v_crop.yield_max - v_crop.yield_min + 1))::integer + v_crop.yield_min;
    insert into public.inventory(owner_id, item_id, quantity) values (v_user, v_plot.crop_id, v_qty)
      on conflict (owner_id, item_id) do update set quantity = public.inventory.quantity + excluded.quantity;
    update public.farm_plots set crop_id = null, planted_at = null, watered = false
      where owner_id = v_user and plot_index = p_plot_index;
    update public.farms set xp = xp + 5, updated_at = now() where owner_id = v_user;
  end if;

  select coins, xp, level into v_coins, v_xp, v_old_level
    from public.farms where owner_id = v_user;
  v_new_level := greatest(1, (v_xp / 50) + 1);
  if v_new_level > v_old_level then
    update public.farms set coins = coins + 25, level = v_new_level, updated_at = now()
      where owner_id = v_user;
    v_coins := v_coins + 25;
  else
    update public.farms set level = v_new_level, updated_at = now() where owner_id = v_user;
  end if;
  return jsonb_build_object('ok', true, 'action', p_action, 'plot_index', p_plot_index,
    'coins', v_coins, 'xp', v_xp, 'level', v_new_level, 'yield', coalesce(v_qty, 0));
end;
$$;

create or replace function public.buy_seeds(p_crop_id text, p_quantity integer)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare v_user uuid := auth.uid(); v_crop record; v_cost bigint;
begin
  if v_user is null then raise exception 'Authentication required'; end if;
  if p_quantity < 1 or p_quantity > 50 then raise exception 'Invalid quantity'; end if;
  select * into v_crop from public.crop_config(p_crop_id);
  if not found then raise exception 'Unknown crop'; end if;
  v_cost := v_crop.seed_price * p_quantity;
  update public.farms set coins = coins - v_cost, updated_at = now()
    where owner_id = v_user and coins >= v_cost;
  if not found then raise exception 'Not enough coins'; end if;
  insert into public.inventory(owner_id, item_id, quantity) values (v_user, 'seed_' || p_crop_id, p_quantity)
    on conflict (owner_id, item_id) do update set quantity = public.inventory.quantity + excluded.quantity;
  return jsonb_build_object('ok', true, 'coins_spent', v_cost, 'quantity', p_quantity);
end;
$$;

create or replace function public.sell_produce(p_item_id text, p_quantity integer)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_user uuid := auth.uid();
  v_crop record;
  v_revenue bigint;
  v_coins bigint;
  v_xp integer;
  v_old_level integer;
  v_new_level integer;
begin
  if v_user is null then raise exception 'Authentication required'; end if;
  if p_quantity < 1 or p_quantity > 500 then raise exception 'Invalid quantity'; end if;
  select * into v_crop from public.crop_config(p_item_id);
  if not found then raise exception 'Unknown produce'; end if;
  update public.inventory set quantity = quantity - p_quantity
    where owner_id = v_user and item_id = p_item_id and quantity >= p_quantity;
  if not found then raise exception 'Not enough produce'; end if;
  v_revenue := v_crop.sell_price * p_quantity;
  update public.farms set coins = coins + v_revenue, xp = xp + p_quantity, updated_at = now()
    where owner_id = v_user;
  select coins, xp, level into v_coins, v_xp, v_old_level
    from public.farms where owner_id = v_user;
  v_new_level := greatest(1, (v_xp / 50) + 1);
  if v_new_level > v_old_level then
    update public.farms set coins = coins + 25, level = v_new_level, updated_at = now()
      where owner_id = v_user;
    v_coins := v_coins + 25;
  else
    update public.farms set level = v_new_level, updated_at = now() where owner_id = v_user;
  end if;
  return jsonb_build_object('ok', true, 'coins_earned', v_revenue, 'coins', v_coins,
    'xp', v_xp, 'level', v_new_level, 'quantity', p_quantity);
end;
$$;

create or replace function public.create_neighbor_code()
returns text
language plpgsql
security definer
set search_path = public
as $$
declare v_user uuid := auth.uid(); v_code text;
begin
  if v_user is null then raise exception 'Authentication required'; end if;
  v_code := substr(upper(replace(gen_random_uuid()::text, '-', '')), 1, 12);
  insert into public.neighbor_codes(owner_id, code, expires_at)
    values (v_user, v_code, now() + interval '7 days')
  on conflict (owner_id) do update set code = excluded.code, expires_at = excluded.expires_at, created_at = now();
  return v_code;
end;
$$;

create or replace function public.accept_neighbor_code(p_code text)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare v_user uuid := auth.uid(); v_owner uuid;
begin
  if v_user is null then raise exception 'Authentication required'; end if;
  select owner_id into v_owner from public.neighbor_codes
    where code = upper(trim(p_code)) and expires_at > now();
  if v_owner is null then raise exception 'Invite code is invalid or expired'; end if;
  if v_owner = v_user then raise exception 'Cannot add your own farm'; end if;
  insert into public.neighbors(owner_id, neighbor_id) values (v_user, v_owner) on conflict do nothing;
  insert into public.neighbors(owner_id, neighbor_id) values (v_owner, v_user) on conflict do nothing;
  return jsonb_build_object('ok', true, 'neighbor_id', v_owner);
end;
$$;

create or replace function public.set_presence(p_x real, p_y real)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare v_user uuid := auth.uid();
begin
  if v_user is null then raise exception 'Authentication required'; end if;
  insert into public.player_presence(owner_id, x, y, last_seen_at)
    values (v_user, greatest(-1000, least(1000, p_x)), greatest(-1000, least(1000, p_y)), now())
  on conflict (owner_id) do update set x = excluded.x, y = excluded.y, last_seen_at = now();
  return jsonb_build_object('ok', true);
end;
$$;

create or replace function public.get_neighbors()
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare v_user uuid := auth.uid(); v_result jsonb;
begin
  if v_user is null then raise exception 'Authentication required'; end if;
  select jsonb_build_object('neighbors', coalesce(jsonb_agg(jsonb_build_object(
    'user_id', p.id,
    'display_name', p.display_name,
    'farm_name', f.farm_name,
    'level', f.level,
    'is_online', coalesce(pr.last_seen_at > now() - interval '45 seconds', false),
    'x', pr.x,
    'y', pr.y,
    'last_seen_at', pr.last_seen_at,
    'plots', coalesce((select jsonb_agg(jsonb_build_object('plot_index', fp.plot_index, 'crop_id', fp.crop_id, 'planted_at', fp.planted_at, 'watered', fp.watered) order by fp.plot_index)
                       from public.farm_plots fp where fp.owner_id = p.id), '[]'::jsonb),
    'inventory', coalesce((select jsonb_agg(jsonb_build_object('item_id', inv.item_id, 'quantity', inv.quantity) order by inv.item_id)
                           from public.inventory inv where inv.owner_id = p.id), '[]'::jsonb)
  )), '[]'::jsonb))
  into v_result
  from public.neighbors n
  join public.profiles p on p.id = n.neighbor_id
  left join public.farms f on f.owner_id = p.id
  left join public.player_presence pr on pr.owner_id = p.id
  where n.owner_id = v_user;
  return v_result;
end;
$$;

-- RPC functions only; deny anonymous/public execution and grant signed-in clients.
revoke all on function public.crop_config(text) from public, anon, authenticated;
revoke all on function public.get_my_farm() from public, anon;
revoke all on function public.perform_farm_action(integer, text, text) from public, anon;
revoke all on function public.buy_seeds(text, integer) from public, anon;
revoke all on function public.sell_produce(text, integer) from public, anon;
revoke all on function public.create_neighbor_code() from public, anon;
revoke all on function public.accept_neighbor_code(text) from public, anon;
revoke all on function public.set_presence(real, real) from public, anon;
revoke all on function public.get_neighbors() from public, anon;
revoke all on function public.handle_new_farmer() from public, anon, authenticated;

grant execute on function public.get_my_farm() to authenticated;
grant execute on function public.perform_farm_action(integer, text, text) to authenticated;
grant execute on function public.buy_seeds(text, integer) to authenticated;
grant execute on function public.sell_produce(text, integer) to authenticated;
grant execute on function public.create_neighbor_code() to authenticated;
grant execute on function public.accept_neighbor_code(text) to authenticated;
grant execute on function public.set_presence(real, real) to authenticated;
grant execute on function public.get_neighbors() to authenticated;

-- Do not grant direct writes to public.farms, public.farm_plots, or public.inventory.
