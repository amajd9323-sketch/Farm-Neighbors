# Farm Neighbors — Web PWA MVP

Mobile-first farming game that runs in Safari, Chrome and desktop browsers. It can be installed on iOS and Android home screens as a Progressive Web App.

## What's included

- Responsive touch-first farm screen with 16 plots.
- Plant, water, grow and harvest wheat, carrots, tomatoes and corn.
- Coins, seeds, inventory, selling, XP and levels.
- Arabic RTL and English LTR localization.
- PWA manifest, service worker, install instructions and app icons.
- Local preview mode saved on the current device.
- Supabase Auth, PostgreSQL RPC economy and neighbor invites when configured.
- Neighbor list, visit view, online heartbeat and Supabase Realtime subscription with polling fallback.

## Run locally

Serve this directory over HTTP (not `file://`):

```bash
python -m http.server 8080
```

Open `http://localhost:8080`.

## Configure online play

1. Create a Supabase project.
2. Run `../Backend/supabase/migrations/20261126090000_initial.sql` in Supabase SQL Editor.
3. Run `../Backend/supabase/migrations/20261126100000_enable_presence_realtime.sql`.
4. Copy your Supabase Project URL and public anon/publishable key into `config.js`.
5. Never put a `service_role` or secret key in browser code.
6. Host this directory over HTTPS. PWA install and service worker require HTTPS, except localhost.

The SQL migration is the source of truth for coins, inventory and crop actions. Browser code calls RPC functions; it does not write economy tables directly.

## iPhone install

Open the HTTPS game URL in Safari → Share → Add to Home Screen → enable Open as Web App → Add.

## Android install

Open the HTTPS game URL in Chrome → Install app (or browser menu → Add to Home screen).

## Important MVP scope

Preview mode is single-device only. Online auth, per-player persistence, neighbor invite codes, and neighbor farm views use Supabase after configuration. This MVP does not yet include player avatars moving in a shared real-time scene, chat, direct trading, animals, crafting, fishing, mining, seasons or push notifications. Verify online behavior with two real devices after deploying and configuring Supabase.
