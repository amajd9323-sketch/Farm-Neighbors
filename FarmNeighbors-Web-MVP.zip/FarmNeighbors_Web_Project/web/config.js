/* Configure with your Supabase project's public URL and publishable/anon key.
   Never put a service_role or secret key in this file. */
window.FARM_NEIGHBORS_CONFIG = {
  SUPABASE_URL: "",
  SUPABASE_ANON_KEY: ""
};
