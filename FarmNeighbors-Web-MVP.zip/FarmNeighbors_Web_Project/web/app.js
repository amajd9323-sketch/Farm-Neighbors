const SUPABASE_CONFIG = window.FARM_NEIGHBORS_CONFIG || {};
const CROPS = {
  wheat: { icon: '🌾', seed: 'seed_wheat', growth: 45, seedPrice: 3, sellPrice: 4, min: 2, max: 4, nameKey: 'cropWheat' },
  carrot: { icon: '🥕', seed: 'seed_carrot', growth: 65, seedPrice: 5, sellPrice: 6, min: 2, max: 3, nameKey: 'cropCarrot' },
  tomato: { icon: '🍅', seed: 'seed_tomato', growth: 90, seedPrice: 7, sellPrice: 8, min: 2, max: 4, nameKey: 'cropTomato' },
  corn: { icon: '🌽', seed: 'seed_corn', growth: 120, seedPrice: 8, sellPrice: 10, min: 2, max: 3, nameKey: 'cropCorn' }
};
const PRODUCE_KEYS = ['wheat', 'carrot', 'tomato', 'corn'];
const STORAGE_KEY = 'farm-neighbors-preview-v1';
const ui = Object.fromEntries([
  'auth-screen','game-screen','auth-form','email','password','name-field','display-name','sign-in','sign-up','guest-button','auth-feedback','auth-note',
  'connection-pill','lang-toggle','sound-toggle','install-button','account-button','farm-title','farm-greeting','level-value','xp-progress','xp-value','coins-value','gems-value','storage-value',
  'plot-count','farm-grid','crop-picker','task-progress','task-count','neighbors-list','inventory-list','sell-all','open-seeds','open-inventory','invite-button','invite-code','join-button',
  'modal-layer','modal-title','modal-eyebrow','modal-content','modal-close','toast','brand-subtitle','neighbor-visit-panel','visit-title','visit-grid','close-visit'
].map(id => [id, document.getElementById(id)]));

let locale = localStorage.getItem('farm-neighbors-language') || ((navigator.language || 'en').toLowerCase().startsWith('ar') ? 'ar' : 'en');
let dictionary = {};
let supabase = null;
let session = null;
let demoMode = false;
let farmState = null;
let currentCrop = 'wheat';
let taskHarvests = Number(localStorage.getItem('farm-neighbors-daily-harvests') || 0);
let installPrompt = null;
let realtimeChannel = null;
let presenceTimer = null;
let neighborCache = [];
let soundEnabled = false;

function t(key) { return dictionary[key] || key; }
function escapeHtml(value) { return String(value ?? '').replace(/[&<>"']/g, ch => ({ '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;' }[ch])); }
function number(value) { return new Intl.NumberFormat(locale === 'ar' ? 'ar' : 'en').format(Number(value || 0)); }
function dateNow() { return new Date().toISOString(); }
function clone(value) { return JSON.parse(JSON.stringify(value)); }
function isConfigured() { return Boolean(SUPABASE_CONFIG.SUPABASE_URL && SUPABASE_CONFIG.SUPABASE_ANON_KEY); }

async function setLocale(nextLocale) {
  locale = nextLocale === 'ar' ? 'ar' : 'en';
  localStorage.setItem('farm-neighbors-language', locale);
  try {
    const response = await fetch(`locales/${locale}.json`, { cache: 'no-store' });
    if (!response.ok) throw new Error('Locale file missing');
    dictionary = await response.json();
  } catch (error) {
    console.error('Localization load failed:', error);
    dictionary = {};
  }
  document.documentElement.lang = locale;
  document.documentElement.dir = locale === 'ar' ? 'rtl' : 'ltr';
  document.querySelectorAll('[data-i18n]').forEach(node => {
    const value = t(node.dataset.i18n);
    if (value !== node.dataset.i18n) node.textContent = value;
  });
  ui.langToggle.textContent = locale === 'ar' ? 'EN' : 'ع';
  if (farmState) renderAll();
}

function createDemoState() {
  return {
    farm: { farm_name: locale === 'ar' ? 'مزرعتي الصغيرة' : 'Sunny Acres', coins: 120, gems: 0, xp: 0, level: 1 },
    plots: Array.from({ length: 16 }, (_, plot_index) => ({ plot_index, crop_id: null, planted_at: null, watered: false })),
    inventory: [
      { item_id: 'seed_wheat', quantity: 10 }, { item_id: 'seed_carrot', quantity: 0 },
      { item_id: 'seed_tomato', quantity: 0 }, { item_id: 'seed_corn', quantity: 0 },
      { item_id: 'wheat', quantity: 0 }, { item_id: 'carrot', quantity: 0 },
      { item_id: 'tomato', quantity: 0 }, { item_id: 'corn', quantity: 0 }
    ]
  };
}
function saveDemoState() {
  if (!demoMode || !farmState) return;
  localStorage.setItem(STORAGE_KEY, JSON.stringify(farmState));
}
function inventoryQty(itemId) { return Number(farmState?.inventory?.find(item => item.item_id === itemId)?.quantity || 0); }
function setInventoryQty(itemId, qty) {
  let item = farmState.inventory.find(row => row.item_id === itemId);
  if (!item) { item = { item_id: itemId, quantity: 0 }; farmState.inventory.push(item); }
  item.quantity = Math.max(0, qty);
}
function cropName(cropId) { return t(CROPS[cropId]?.nameKey || cropId); }
function cropEmoji(cropId) { return CROPS[cropId]?.icon || '🌱'; }
function plotAt(index) { return farmState.plots.find(plot => Number(plot.plot_index) === index); }
function cropRemaining(plot) {
  if (!plot?.crop_id || !plot.planted_at) return 0;
  const seconds = CROPS[plot.crop_id]?.growth || 45;
  const finish = new Date(plot.planted_at).getTime() + seconds * 1000;
  return Math.max(0, Math.ceil((finish - Date.now()) / 1000));
}
function xpProgress() {
  const xp = Number(farmState?.farm?.xp || 0);
  return { current: xp % 50, needed: 50, percent: (xp % 50) / 50 * 100 };
}
function totalStorage() { return (farmState?.inventory || []).reduce((sum, item) => sum + Number(item.quantity || 0), 0); }

async function callRpc(name, params = {}) {
  if (!supabase || !session) throw new Error(t('previewOnly'));
  const { data, error } = await supabase.rpc(name, params);
  if (error) throw error;
  return data;
}
async function loadFarm() {
  if (demoMode) {
    const saved = localStorage.getItem(STORAGE_KEY);
    try { farmState = saved ? JSON.parse(saved) : createDemoState(); }
    catch { farmState = createDemoState(); }
    saveDemoState();
    return;
  }
  const data = await callRpc('get_my_farm');
  if (!data?.farm) throw new Error('Farm profile missing. Please sign out and sign in again.');
  farmState = data;
}

function showToast(message) {
  ui.toast.textContent = message;
  ui.toast.classList.add('show');
  clearTimeout(showToast.timer);
  showToast.timer = setTimeout(() => ui.toast.classList.remove('show'), 2600);
}
function setConnection(online) {
  ui.connectionPill.classList.toggle('online', Boolean(online));
  ui.connectionPill.querySelector('span').textContent = online ? t('online') : t('offline');
}
function renderAll() {
  if (!farmState) return;
  const farm = farmState.farm;
  ui.farmTitle.textContent = farm.farm_name || (locale === 'ar' ? 'مزرعتي' : 'My Farm');
  ui.levelValue.textContent = number(farm.level);
  ui.coinsValue.textContent = number(farm.coins);
  ui.gemsValue.textContent = number(farm.gems);
  ui.storageValue.textContent = number(totalStorage());
  const progress = xpProgress();
  ui.xpProgress.style.width = `${progress.percent}%`;
  ui.xpValue.textContent = `${number(progress.current)} / 50 XP`;
  const occupied = farmState.plots.filter(plot => plot.crop_id).length;
  ui.plotCount.textContent = `${number(occupied)} / 16`;
  renderPlots();
  renderCropPicker();
  renderInventory();
  renderTask();
  renderNeighbors();
}
function renderPlots() {
  ui.farmGrid.innerHTML = farmState.plots.slice().sort((a,b) => a.plot_index - b.plot_index).map(plot => {
    const index = Number(plot.plot_index);
    if (!plot.crop_id) return `<button class="plot empty" type="button" data-plot="${index}" aria-label="Empty plot ${index + 1}"></button>`;
    const remaining = cropRemaining(plot);
    const ready = remaining <= 0;
    const label = ready ? t('ready') : `${number(remaining)}${t('seconds')}`;
    return `<button class="plot crop ${ready ? 'ready' : ''}" type="button" data-plot="${index}" aria-label="${escapeHtml(cropName(plot.crop_id))}, ${escapeHtml(label)}"><span class="crop-sprout">${cropEmoji(plot.crop_id)}</span><small class="plot-time">${escapeHtml(label)}</small></button>`;
  }).join('');
}
function renderCropPicker() {
  ui.cropPicker.innerHTML = Object.entries(CROPS).map(([id, crop]) => {
    const qty = inventoryQty(crop.seed);
    return `<button class="crop-choice ${currentCrop === id ? 'selected' : ''}" type="button" data-crop="${id}"><span class="crop-symbol">${crop.icon}</span><span><b>${escapeHtml(cropName(id))}</b><small>${number(qty)} ${escapeHtml(t('seed'))}</small></span></button>`;
  }).join('');
}
function renderInventory() {
  const visible = (farmState.inventory || []).filter(item => Number(item.quantity) > 0);
  ui.inventoryList.innerHTML = visible.length ? visible.map(item => {
    const isSeed = item.item_id.startsWith('seed_');
    const cropId = isSeed ? item.item_id.slice(5) : item.item_id;
    return `<div class="inventory-item"><span>${cropEmoji(cropId)}</span><div><b>${escapeHtml(cropName(cropId))}</b><small>${isSeed ? escapeHtml(t('seed')) : escapeHtml(t('harvestCount'))}</small></div><strong>${number(item.quantity)}</strong></div>`;
  }).join('') : `<p class="empty-note">${locale === 'ar' ? 'المخزن فارغ حاليًا.' : 'Your barn is empty for now.'}</p>`;
}
function renderTask() {
  const count = Math.min(3, taskHarvests % 4);
  document.getElementById('task-progress').style.width = `${count / 3 * 100}%`;
  document.getElementById('task-count').textContent = `${number(count)} / 3`;
}
function renderNeighbors() {
  ui.neighborsList.innerHTML = neighborCache.length ? neighborCache.map((neighbor, index) => `
    <div class="neighbor-card"><span class="neighbor-avatar">${escapeHtml((neighbor.display_name || 'F').slice(0,1).toUpperCase())}</span>
      <div class="neighbor-info"><b>${escapeHtml(neighbor.display_name || 'Farmer')}</b><small>${escapeHtml(neighbor.farm_name || 'Farm')} · ${t('level')} ${number(neighbor.level)}</small></div>
      <i class="online-dot" style="opacity:${neighbor.is_online ? 1 : .25}"></i>
      <button class="visit-button" type="button" data-visit="${index}">${escapeHtml(t('visit'))}</button></div>`).join('') : `<p class="empty-note">${escapeHtml(t('noNeighbors'))}</p>`;
}

async function refreshNeighbors() {
  if (demoMode || !session) return;
  try {
    const result = await callRpc('get_neighbors');
    neighborCache = result?.neighbors || [];
    renderNeighbors();
  } catch (error) { console.warn('Neighbor refresh failed:', error.message); }
}
async function sendPresence() {
  if (demoMode || !session) return;
  try { await callRpc('set_presence', { p_x: 0, p_y: 0 }); }
  catch (error) { console.warn('Presence update failed:', error.message); }
}
function startOnlineServices() {
  stopOnlineServices();
  if (!session || demoMode) return;
  refreshNeighbors();
  sendPresence();
  presenceTimer = setInterval(() => { sendPresence(); refreshNeighbors(); }, 12000);
  if (supabase) {
    realtimeChannel = supabase.channel(`farm-presence-${session.user.id}`)
      .on('postgres_changes', { event: '*', schema: 'public', table: 'player_presence' }, () => refreshNeighbors())
      .subscribe(status => { if (status === 'CHANNEL_ERROR') console.warn('Realtime channel error; polling remains active.'); });
  }
}
function stopOnlineServices() {
  if (presenceTimer) clearInterval(presenceTimer);
  presenceTimer = null;
  if (realtimeChannel && supabase) supabase.removeChannel(realtimeChannel);
  realtimeChannel = null;
}

function showGame() {
  ui.authScreen.hidden = true;
  ui.gameScreen.hidden = false;
  ui.accountButton.hidden = demoMode;
  ui.accountButton.textContent = (session?.user?.email || 'F').slice(0,1).toUpperCase();
  ui.brandSubtitle.textContent = demoMode ? t('demoMode') : t('signedInAs');
  setConnection(!demoMode && Boolean(session));
  renderAll();
}
function showAuth(message = '') {
  stopOnlineServices();
  ui.gameScreen.hidden = true;
  ui.authScreen.hidden = false;
  ui.accountButton.hidden = true;
  ui.authFeedback.textContent = message;
  setConnection(false);
}

async function initSupabase() {
  if (!isConfigured()) return false;
  try {
    const { createClient } = await import('https://esm.sh/@supabase/supabase-js@2');
    supabase = createClient(SUPABASE_CONFIG.SUPABASE_URL, SUPABASE_CONFIG.SUPABASE_ANON_KEY, {
      auth: { persistSession: true, autoRefreshToken: true, detectSessionInUrl: true }
    });
    const { data, error } = await supabase.auth.getSession();
    if (error) throw error;
    session = data.session;
    supabase.auth.onAuthStateChange((_event, nextSession) => {
      session = nextSession;
      if (!session) { farmState = null; neighborCache = []; showAuth(); }
    });
    return true;
  } catch (error) {
    console.error('Supabase init failed:', error);
    ui.authFeedback.textContent = locale === 'ar' ? 'تعذر الاتصال بالخادم. يمكنك تجربة وضع المعاينة.' : 'Could not connect to the game server. You can try preview mode.';
    return false;
  }
}

async function enterAccount() {
  demoMode = false;
  await loadFarm();
  showGame();
  startOnlineServices();
  ui.farmGreeting.textContent = t('welcomeBack');
}
async function startDemo() {
  demoMode = true;
  session = null;
  neighborCache = [];
  await loadFarm();
  showGame();
  ui.farmGreeting.textContent = t('offlineSave');
  showToast(t('offlineSave'));
}
async function authAction(mode) {
  if (!supabase) { ui.authFeedback.textContent = t('previewOnly'); return; }
  const email = ui.email.value.trim();
  const password = ui.password.value;
  const displayName = document.getElementById('display-name').value.trim();
  ui.authFeedback.textContent = locale === 'ar' ? 'جارٍ الاتصال...' : 'Connecting...';
  try {
    let response;
    if (mode === 'signup') {
      response = await supabase.auth.signUp({ email, password, options: { data: { display_name: displayName || email.split('@')[0] } } });
      if (response.error) throw response.error;
      if (!response.data.session) {
        ui.authFeedback.textContent = t('accountCreated');
        return;
      }
      session = response.data.session;
    } else {
      response = await supabase.auth.signInWithPassword({ email, password });
      if (response.error) throw response.error;
      session = response.data.session;
    }
    await enterAccount();
  } catch (error) {
    console.error('Authentication failed:', error);
    ui.authFeedback.textContent = error.message || t('authError');
  }
}

async function farmAction(index, action) {
  try {
    if (demoMode) {
      const plot = plotAt(index);
      if (!plot) return;
      if (action === 'plant') {
        if (plot.crop_id) throw new Error(t('plotOccupied'));
        const seedId = CROPS[currentCrop].seed;
        if (inventoryQty(seedId) < 1) throw new Error(t('notEnough'));
        setInventoryQty(seedId, inventoryQty(seedId) - 1);
        plot.crop_id = currentCrop;
        plot.planted_at = dateNow();
        plot.watered = false;
      } else if (action === 'water') {
        if (!plot.crop_id) throw new Error(t('emptyPlot'));
        if (plot.watered) throw new Error(locale === 'ar' ? 'تم سقي هذا المحصول بالفعل.' : 'This crop was already watered.');
        const growth = CROPS[plot.crop_id].growth;
        plot.planted_at = new Date(new Date(plot.planted_at).getTime() - growth * 200).toISOString();
        plot.watered = true;
      } else if (action === 'harvest') {
        const remaining = cropRemaining(plot);
        if (remaining > 0) throw new Error(t('notReady'));
        const crop = CROPS[plot.crop_id];
        const qty = Math.floor(Math.random() * (crop.max - crop.min + 1)) + crop.min;
        setInventoryQty(plot.crop_id, inventoryQty(plot.crop_id) + qty);
        farmState.farm.xp += 5;
        updateDemoLevel();
        plot.crop_id = null; plot.planted_at = null; plot.watered = false;
        taskHarvests++;
        localStorage.setItem('farm-neighbors-daily-harvests', String(taskHarvests));
      }
      saveDemoState();
    } else {
      const result = await callRpc('perform_farm_action', { p_plot_index: index, p_action: action, p_crop_id: currentCrop });
      if (action === 'harvest') {
        taskHarvests++;
        localStorage.setItem('farm-neighbors-daily-harvests', String(taskHarvests));
        if (result?.yield) showToast(`${t('harvested')} +${number(result.yield)} ${cropName(currentCrop)}`);
      }
      await loadFarm();
    }
    renderAll();
    if (action === 'plant') showToast(t('planted'));
    else if (action === 'water') showToast(t('watered'));
    else showToast(t('harvested'));
  } catch (error) { showToast(error.message || t('authError')); }
}
function updateDemoLevel() {
  const oldLevel = farmState.farm.level;
  const nextLevel = Math.floor(farmState.farm.xp / 50) + 1;
  if (nextLevel > oldLevel) {
    farmState.farm.level = nextLevel;
    farmState.farm.coins += 25;
    showToast(t('levelUp'));
  }
}

function openModal(title, eyebrow, content) {
  ui.modalTitle.textContent = title;
  ui.modalEyebrow.textContent = eyebrow;
  ui.modalContent.innerHTML = content;
  ui.modalLayer.hidden = false;
}
function closeModal() { ui.modalLayer.hidden = true; }
function openSeedShop() {
  const content = Object.entries(CROPS).map(([id, crop]) => `
    <div class="shop-item"><span class="shop-icon">${crop.icon}</span><div class="shop-copy"><b>${escapeHtml(cropName(id))}</b><small>${number(crop.growth)}${t('seconds')} · ${number(crop.sellPrice)} C ${t('sellValue')}</small></div><button class="shop-buy" data-buy="${id}" type="button">${number(crop.seedPrice)} C · +5</button></div>`).join('');
  openModal(t('seedShop'), t('shopTitle'), content);
}
async function buySeeds(cropId) {
  try {
    if (demoMode) {
      const crop = CROPS[cropId];
      const quantity = 5;
      const cost = crop.seedPrice * quantity;
      if (farmState.farm.coins < cost) throw new Error(t('notEnough'));
      farmState.farm.coins -= cost;
      setInventoryQty(crop.seed, inventoryQty(crop.seed) + quantity);
      saveDemoState();
    } else {
      await callRpc('buy_seeds', { p_crop_id: cropId, p_quantity: 5 });
      await loadFarm();
    }
    currentCrop = cropId;
    closeModal(); renderAll(); showToast(t('seedBought'));
  } catch (error) { showToast(error.message || t('authError')); }
}
async function sellAllProduce() {
  const produce = PRODUCE_KEYS.map(id => ({ id, qty: inventoryQty(id) })).filter(item => item.qty > 0);
  if (!produce.length) { showToast(locale === 'ar' ? 'لا توجد محاصيل للبيع.' : 'No produce to sell.'); return; }
  if (!confirm(t('sellConfirm'))) return;
  try {
    if (demoMode) {
      for (const item of produce) {
        farmState.farm.coins += CROPS[item.id].sellPrice * item.qty;
        farmState.farm.xp += item.qty;
        setInventoryQty(item.id, 0);
      }
      updateDemoLevel(); saveDemoState();
    } else {
      for (const item of produce) await callRpc('sell_produce', { p_item_id: item.id, p_quantity: item.qty });
      await loadFarm();
    }
    renderAll(); showToast(t('sold'));
  } catch (error) { showToast(error.message || t('authError')); }
}

async function createInvite() {
  try {
    const code = await callRpc('create_neighbor_code');
    openModal(t('inviteTitle'), t('yourCircle'), `<p class="modal-note">${escapeHtml(t('inviteDesc'))}</p><div class="code-box"><strong id="invite-code-value">${escapeHtml(code)}</strong><button id="copy-invite" type="button">${escapeHtml(t('copyCode'))}</button></div><p class="modal-note">${escapeHtml(window.location.href.split('?')[0])}</p>`);
    document.getElementById('copy-invite').addEventListener('click', async () => {
      try { await navigator.clipboard.writeText(code); showToast(t('inviteCopied')); }
      catch { showToast(code); }
    });
  } catch (error) { showToast(demoMode ? t('previewOnly') : (error.message || t('authError'))); }
}
async function joinNeighbor() {
  const code = ui.inviteCode.value.trim().toUpperCase();
  if (!code) return;
  try {
    await callRpc('accept_neighbor_code', { p_code: code });
    ui.inviteCode.value = '';
    await refreshNeighbors();
    showToast(t('neighborJoined'));
  } catch (error) { showToast(error.message || t('invalidCode')); }
}
function visitNeighbor(index) {
  const neighbor = neighborCache[index];
  if (!neighbor) return;
  document.getElementById('visit-title').textContent = neighbor.farm_name || neighbor.display_name;
  const plots = neighbor.plots || [];
  ui.visitGrid.innerHTML = plots.map(plot => `<div class="visit-plot">${plot.crop_id ? cropEmoji(plot.crop_id) : ''}</div>`).join('');
  ui.neighborVisitPanel.hidden = false;
  ui.neighborVisitPanel.scrollIntoView({ behavior: 'smooth', block: 'center' });
}
function showPlotOptions(index) {
  const plot = plotAt(index);
  if (!plot) return;
  if (!plot.crop_id) { farmAction(index, 'plant'); return; }
  const remaining = cropRemaining(plot);
  const actionButton = remaining <= 0
    ? `<button class="primary-button" id="plot-harvest" type="button">${escapeHtml(t('harvested'))}</button>`
    : `<button class="primary-button" id="plot-water" type="button">${escapeHtml(t('watered'))} · 20%</button>`;
  openModal(cropName(plot.crop_id), t('theLand'), `<p class="modal-note">${remaining <= 0 ? escapeHtml(t('ready')) : `${escapeHtml(t('growing'))}: ${number(remaining)} ${escapeHtml(t('seconds'))}`}</p><div class="shop-item"><span class="shop-icon">${cropEmoji(plot.crop_id)}</span><div class="shop-copy"><b>${escapeHtml(cropName(plot.crop_id))}</b><small>${plot.watered ? (locale === 'ar' ? 'تم السقي' : 'Watered') : (locale === 'ar' ? 'لم يُسقَ بعد' : 'Not watered yet')}</small></div>${actionButton}</div>`);
  const harvest = document.getElementById('plot-harvest');
  const water = document.getElementById('plot-water');
  if (harvest) harvest.addEventListener('click', () => { closeModal(); farmAction(index, 'harvest'); });
  if (water) water.addEventListener('click', () => { closeModal(); farmAction(index, 'water'); });
}

function playClick() {
  if (!soundEnabled) return;
  try {
    const context = new (window.AudioContext || window.webkitAudioContext)();
    const oscillator = context.createOscillator();
    const gain = context.createGain();
    oscillator.type = 'sine'; oscillator.frequency.value = 620;
    gain.gain.setValueAtTime(.035, context.currentTime);
    gain.gain.exponentialRampToValueAtTime(.001, context.currentTime + .08);
    oscillator.connect(gain); gain.connect(context.destination);
    oscillator.start(); oscillator.stop(context.currentTime + .08);
    oscillator.onended = () => context.close();
  } catch { /* Audio unavailable on this device. */ }
}

function bindEvents() {
  ui.authForm.addEventListener('submit', event => { event.preventDefault(); authAction(ui.nameField.hidden ? 'signin' : 'signup'); });
  ui.signUp.addEventListener('click', () => {
    ui.nameField.hidden = !ui.nameField.hidden;
    ui.signIn.textContent = ui.nameField.hidden ? t('signIn') : t('createAccount');
    ui.authFeedback.textContent = '';
  });
  ui.guestButton.addEventListener('click', startDemo);
  ui.langToggle.addEventListener('click', () => setLocale(locale === 'ar' ? 'en' : 'ar'));
  ui.installButton.addEventListener('click', async () => {
    if (installPrompt) {
      installPrompt.prompt();
      await installPrompt.userChoice;
      installPrompt = null;
      return;
    }
    const instructions = locale === 'ar'
      ? '<p class="modal-note">على iPhone: افتح الرابط في Safari، اضغط زر المشاركة، ثم اختر <b>Add to Home Screen</b> واضغط Add.</p><p class="modal-note">على Android: افتح الرابط في Chrome، افتح القائمة، ثم اختر <b>Install app</b> أو <b>Add to Home screen</b>.</p>'
      : '<p class="modal-note">On iPhone: open this link in Safari, tap Share, choose <b>Add to Home Screen</b>, then tap Add.</p><p class="modal-note">On Android: open this link in Chrome, open the browser menu, then choose <b>Install app</b> or <b>Add to Home screen</b>.</p>';
    openModal(t('installApp'), 'FARM NEIGHBORS', instructions);
  });

  ui.soundToggle.addEventListener('click', () => { soundEnabled = !soundEnabled; ui.soundToggle.style.background = soundEnabled ? '#e2efdc' : ''; showToast(locale === 'ar' ? (soundEnabled ? 'الصوت مفعّل' : 'الصوت مكتوم') : (soundEnabled ? 'Sound on' : 'Sound muted')); playClick(); });
  ui.accountButton.addEventListener('click', async () => {
    if (!confirm(locale === 'ar' ? 'تسجيل الخروج؟' : 'Sign out?')) return;
    stopOnlineServices();
    if (supabase) await supabase.auth.signOut();
    session = null; farmState = null; neighborCache = []; showAuth(t('signedOut'));
  });
  ui.farmGrid.addEventListener('click', event => { const button = event.target.closest('[data-plot]'); if (button) showPlotOptions(Number(button.dataset.plot)); });
  ui.cropPicker.addEventListener('click', event => { const button = event.target.closest('[data-crop]'); if (!button) return; currentCrop = button.dataset.crop; renderCropPicker(); });
  ui.openSeeds.addEventListener('click', openSeedShop);
  ui.openInventory.addEventListener('click', () => document.querySelector('.inventory-panel').scrollIntoView({ behavior: 'smooth' }));
  ui.sellAll.addEventListener('click', sellAllProduce);
  ui.inviteButton.addEventListener('click', createInvite);
  ui.joinButton.addEventListener('click', joinNeighbor);
  ui.neighborsList.addEventListener('click', event => { const button = event.target.closest('[data-visit]'); if (button) visitNeighbor(Number(button.dataset.visit)); });
  ui.modalClose.addEventListener('click', closeModal);
  ui.modalLayer.addEventListener('click', event => { if (event.target === ui.modalLayer) closeModal(); });
  ui.modalContent.addEventListener('click', event => { const button = event.target.closest('[data-buy]'); if (button) buySeeds(button.dataset.buy); });
  ui.closeVisit.addEventListener('click', () => { ui.neighborVisitPanel.hidden = true; });
  document.querySelector('.mobile-nav').addEventListener('click', event => {
    const button = event.target.closest('[data-nav]'); if (!button) return;
    document.querySelectorAll('.nav-item').forEach(item => item.classList.toggle('active', item === button));
    const target = button.dataset.nav;
    if (target === 'farm') document.querySelector('.farm-panel').scrollIntoView({ behavior: 'smooth' });
    if (target === 'inventory') document.querySelector('.inventory-panel').scrollIntoView({ behavior: 'smooth' });
    if (target === 'neighbors') document.querySelector('.neighbor-panel').scrollIntoView({ behavior: 'smooth' });
    if (target === 'shop') openSeedShop();
  });
  window.addEventListener('online', () => { if (!demoMode && session) { setConnection(true); refreshNeighbors(); } });
  window.addEventListener('offline', () => setConnection(false));
  window.addEventListener('beforeinstallprompt', event => { event.preventDefault(); installPrompt = event; ui.installButton.classList.add('install-ready'); });
  window.addEventListener('appinstalled', () => { installPrompt = null; showToast(locale === 'ar' ? 'تم تثبيت اللعبة.' : 'Game installed.'); });
  document.addEventListener('visibilitychange', () => { if (!document.hidden && session && !demoMode) { loadFarm().then(renderAll).catch(console.error); refreshNeighbors(); } });
}

async function bootstrap() {
  bindEvents();
  await setLocale(locale);
  setInterval(() => { if (farmState) renderPlots(); }, 1000);
  if ('serviceWorker' in navigator && (location.protocol === 'https:' || location.hostname === 'localhost')) {
    navigator.serviceWorker.register('./sw.js').catch(error => console.warn('Service worker registration failed:', error));
  }
  const configured = await initSupabase();
  if (configured && session) {
    try { await enterAccount(); }
    catch (error) { console.error('Could not load farm:', error); showAuth(error.message || t('authError')); }
  } else {
    showAuth();
    if (!isConfigured()) ui.authNote.textContent = t('authNote');
  }
}

bootstrap().catch(error => {
  console.error('Farm Neighbors failed to start:', error);
  showAuth(error.message || 'App could not start.');
});
