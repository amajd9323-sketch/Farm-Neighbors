# Farm Neighbors — Web PWA MVP

Mobile-first farming game for iPhone, Android and desktop browsers. Installable as a Progressive Web App.

- 16 farm plots, 4 crops, planting, watering, harvesting
- Coins, seeds, inventory, sales, XP and levels
- Arabic RTL + English LTR
- Local preview mode
- Supabase Auth + PostgreSQL RPC economy + neighbor invites
- PWA manifest, service worker and install guidance

See [Arabic setup guide](README_AR.md) and [web README](web/README.md).

## Quick start

Run from `web/`:

```bash
python -m http.server 8080
```

Open `http://localhost:8080`. Choose **Try farm preview** for local play.

For online play, run both SQL migrations in `Backend/supabase/migrations`, configure `web/config.js` with the Supabase Project URL and public anon/publishable key, then deploy `web/` to an HTTPS host. Never expose a Supabase service-role or secret key in browser code.

## Scope

This is an early web MVP, not a finished online multiplayer title. Account-backed farm persistence and neighbor invitations are wired to Supabase. Two-device testing, shared live character movement, chat, direct trading, animals, production and events remain outstanding.
